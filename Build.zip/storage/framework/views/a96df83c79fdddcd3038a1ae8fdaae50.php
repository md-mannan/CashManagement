<!DOCTYPE html>
<html lang="en-GB"
    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'dark' => ($appearance ?? 'system') == 'dark',
        'theme-violet' => ($theme ?? 'neutral') == 'violet'
    ]); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        

        
        <script>
            (function() {
                const appearance = '<?php echo e($appearance ?? "system"); ?>';
                const theme = '<?php echo e($theme ?? "neutral"); ?>';

                if (appearance === 'system') {
                    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

                    if (prefersDark) {
                        document.documentElement.classList.add('dark');
                    }
                }

                // Apply theme class
                if (theme !== 'neutral') {
                    document.documentElement.classList.add(`theme-${theme}`);
                }
            })();
        </script>

        
        <style>
            html {
                background-color: oklch(1 0 0);
            }

            html.dark {
                background-color: oklch(0.145 0 0);
            }

            html.theme-violet {
                background-color: oklch(0.99 0.005 280);
            }

            html.theme-violet.dark {
                background-color: oklch(0.12 0.02 280);
            }
        </style>

        <title inertia><?php echo e(config('app.name', 'Laravel')); ?></title>

        <link rel="icon" href="/favicon.ico" sizes="any">
        <link rel="icon" href="/favicon.svg" type="image/svg+xml">
        <link rel="apple-touch-icon" href="/apple-touch-icon.png">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
        
        <?php if(app()->environment('local', 'development')): ?>
            
            <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.tsx']); ?>
        <?php else: ?>
            
            <?php
                $manifest = public_path('build/.vite/manifest.json');
                if (file_exists($manifest)) {
                    $manifestData = json_decode(file_get_contents($manifest), true);
                    $appJs = $manifestData['resources/js/app.tsx']['file'] ?? null;
                    $appCss = $manifestData['resources/js/app.tsx']['css'][0] ?? null;
                }
            ?>
            
            <?php if(isset($appCss)): ?>
                <link rel="stylesheet" href="<?php echo e(asset('build/' . $appCss)); ?>">
            <?php endif; ?>
            
            <?php if(isset($appJs)): ?>
                <script type="module" src="<?php echo e(asset('build/' . $appJs)); ?>"></script>
            <?php else: ?>
                
                <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.tsx']); ?>
            <?php endif; ?>
        <?php endif; ?>
        
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="font-sans antialiased">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html>
<?php /**PATH /home/mannan/Desktop/Projects/CashManagement/resources/views/app.blade.php ENDPATH**/ ?>