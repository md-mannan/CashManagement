-- Table structure for table `activity_logs`
DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `target_type` varchar(255) DEFAULT NULL,
  `target_id` bigint(20) unsigned DEFAULT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_logs_user_id_action_index` (`user_id`,`action`),
  KEY `activity_logs_target_type_target_id_index` (`target_type`,`target_id`),
  KEY `activity_logs_created_at_index` (`created_at`),
  KEY `activity_logs_action_index` (`action`),
  CONSTRAINT `activity_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `cache`
DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `cache`
INSERT INTO `cache` VALUES
('laravel_cache_avg_response_time', 'i:68;', 1754826345),
('laravel_cache_cache_hit_rate', 'd:0.98;', 1754826346),
('laravel_cache_error_rate', 'd:0.005;', 1754826345),
('laravel_cache_health_check', 's:2:\"ok\";', 1754826112);

-- Table structure for table `cache_locks`
DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `categories`
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL DEFAULT '#6B7280',
  `icon` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `categories`
INSERT INTO `categories` VALUES
(1, 'Salary', 'salary', 'income', '#10B981', 'Banknote', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(2, 'Freelance', 'freelance', 'income', '#059669', 'Laptop', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(3, 'Investment', 'investment', 'income', '#0D9488', 'TrendingUp', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(4, 'Business', 'business', 'income', '#0891B2', 'Building', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(5, 'Other Income', 'other-income', 'income', '#0EA5E9', 'Plus', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(6, 'Food & Dining', 'food-dining', 'expense', '#EF4444', 'UtensilsCrossed', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(7, 'Transportation', 'transportation', 'expense', '#DC2626', 'Car', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(8, 'Utilities', 'utilities', 'expense', '#B91C1C', 'Zap', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(9, 'Shopping', 'shopping', 'expense', '#991B1B', 'ShoppingBag', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(10, 'Entertainment', 'entertainment', 'expense', '#7C2D12', 'Film', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(11, 'Healthcare', 'healthcare', 'expense', '#92400E', 'Heart', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(12, 'Education', 'education', 'expense', '#B45309', 'BookOpen', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(13, 'Other Expenses', 'other-expenses', 'expense', '#D97706', 'Minus', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(14, 'Client Payment', 'client-payment', 'receivable', '#8B5CF6', 'Users', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(15, 'Loan Repayment', 'loan-repayment', 'receivable', '#7C3AED', 'HandCoins', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(16, 'Rental Payment', 'rental-payment', 'receivable', '#6D28D9', 'Home', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(17, 'Credit Card', 'credit-card', 'payable', '#F59E0B', 'CreditCard', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(18, 'Rent', 'rent', 'payable', '#D97706', 'Home', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(19, 'Taxes', 'taxes', 'payable', '#B45309', 'FileText', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19'),
(20, 'Insurance', 'insurance', 'payable', '#92400E', 'Shield', 1, '2025-08-10 09:32:19', '2025-08-10 09:32:19');

-- Table structure for table `exchange_rates`
DROP TABLE IF EXISTS `exchange_rates`;
CREATE TABLE `exchange_rates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `from_currency` varchar(3) NOT NULL,
  `to_currency` varchar(3) NOT NULL,
  `rate` decimal(15,8) NOT NULL,
  `source` varchar(255) NOT NULL DEFAULT 'exchangerate-api.com',
  `fetched_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `exchange_rates_from_currency_to_currency_unique` (`from_currency`,`to_currency`),
  KEY `exchange_rates_from_currency_to_currency_fetched_at_index` (`from_currency`,`to_currency`,`fetched_at`),
  KEY `exchange_rates_fetched_at_index` (`fetched_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `exchange_rates`
INSERT INTO `exchange_rates` VALUES
(1, 'EUR', 'USD', '1.16000000', 'exchangerate-api.com', '2025-08-10 10:42:42', '2025-08-10 09:45:20', '2025-08-10 10:42:42'),
(2, 'EUR', 'BDT', '141.57480000', 'exchangerate-api.com', '2025-08-10 10:42:44', '2025-08-10 09:45:23', '2025-08-10 10:42:44'),
(3, 'KWD', 'BDT', '400.28770000', 'exchangerate-api.com', '2025-08-10 10:42:47', '2025-08-10 09:45:30', '2025-08-10 10:42:47'),
(4, 'KWD', 'USD', '3.27240000', 'exchangerate-api.com', '2025-08-10 10:40:19', '2025-08-10 10:40:19', '2025-08-10 10:40:19');

-- Table structure for table `failed_jobs`
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `job_batches`
DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `jobs`
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `migrations`
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `migrations`
INSERT INTO `migrations` VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_08_08_203705_add_currency_fields_to_users_table', 1),
(5, '2025_08_09_045439_create_categories_table', 1),
(6, '2025_08_09_045440_create_transactions_table', 1),
(7, '2025_08_09_054225_add_appearance_fields_to_users_table', 1),
(8, '2025_08_09_122749_create_exchange_rates_table', 1),
(9, '2025_08_09_123106_add_exchange_rate_api_key_to_users_table', 1),
(10, '2025_08_09_162444_create_notifications_table', 1),
(11, '2025_08_09_165238_add_admin_role_to_users_table', 1),
(12, '2025_08_09_170430_add_role_and_permissions_to_users_table', 1),
(13, '2025_08_09_192206_remove_admin_role_columns_from_users_table', 1),
(14, '2025_08_10_000000_create_social_accounts_table', 1),
(15, '2025_08_10_000001_add_password_reset_fields_to_users_table', 1),
(16, '2025_08_10_000002_create_activity_logs_table', 1);

-- Table structure for table `notifications`
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) NOT NULL DEFAULT 'blue',
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `read_at` timestamp NULL DEFAULT NULL,
  `is_important` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_read_at_index` (`user_id`,`read_at`),
  KEY `notifications_user_id_created_at_index` (`user_id`,`created_at`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `password_reset_tokens`
DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `sessions`
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `social_accounts`
DROP TABLE IF EXISTS `social_accounts`;
CREATE TABLE `social_accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `provider` varchar(255) NOT NULL,
  `provider_user_id` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `refresh_token` varchar(255) DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `social_accounts_provider_provider_user_id_unique` (`provider`,`provider_user_id`),
  KEY `social_accounts_user_id_foreign` (`user_id`),
  CONSTRAINT `social_accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `transactions`
DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  `type` enum('income','expense','receivable','payable') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'USD',
  `source` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('pending','completed','cancelled') NOT NULL DEFAULT 'completed',
  `due_date` timestamp NULL DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_category_id_foreign` (`category_id`),
  KEY `transactions_user_id_date_index` (`user_id`,`date`),
  KEY `transactions_user_id_type_index` (`user_id`,`type`),
  KEY `transactions_user_id_status_index` (`user_id`,`status`),
  CONSTRAINT `transactions_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `users`
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `primary_currency` varchar(3) NOT NULL DEFAULT 'USD',
  `secondary_currency` varchar(3) NOT NULL DEFAULT 'EUR',
  `primary_symbol` varchar(5) NOT NULL DEFAULT '$',
  `secondary_symbol` varchar(5) NOT NULL DEFAULT '€',
  `exchange_rate` decimal(10,4) NOT NULL DEFAULT 1.0000,
  `appearance_mode` enum('light','dark','system') NOT NULL DEFAULT 'system',
  `theme` enum('neutral','violet','blue','green','orange','red') NOT NULL DEFAULT 'neutral',
  `timezone` varchar(50) NOT NULL DEFAULT 'UTC',
  `date_format` varchar(20) NOT NULL DEFAULT 'Y-m-d',
  `time_format` varchar(10) NOT NULL DEFAULT 'H:i',
  `exchange_rate_api_key` varchar(255) DEFAULT NULL,
  `exchange_rate_api_provider` varchar(255) NOT NULL DEFAULT 'exchangerate-api.com',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `password_reset_expires_at` timestamp NULL DEFAULT NULL,
  `force_password_change` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `users`
INSERT INTO `users` VALUES
(1, 'Super Admin', 'admin@cashmanagement.com', 'BDT', 'KWD', '৳', 'د.ك', '400.2877', 'system', 'neutral', 'UTC', 'Y-m-d', 'H:i', NULL, 'exchangerate-api.com', '2025-08-10 09:32:22', 'super_admin', '[\"manage_users\",\"manage_admins\",\"view_analytics\",\"manage_transactions\",\"manage_categories\",\"manage_settings\",\"view_all_transactions\",\"view_all_user_data\",\"access_ledger\",\"manage_system_settings\",\"view_system_logs\",\"export_data\",\"perform_bulk_operations\",\"manage_exchange_rates\",\"manage_currencies\",\"manage_appearance\",\"view_activity_logs\",\"manage_notifications\",\"system_audit\",\"full_system_access\"]', 1, '2025-08-10 09:32:22', '$2y$12$osowrrcI44679vGCO07dFuo9mTgYCwFi/f31besVvUbz1QgXWOLZa', NULL, NULL, NULL, 0, '2025-08-10 09:32:22', '2025-08-10 10:21:08'),
(2, 'Admin User', 'admin@example.com', 'USD', 'EUR', '$', '€', '1.0000', 'system', 'neutral', 'UTC', 'Y-m-d', 'H:i', NULL, 'exchangerate-api.com', '2025-08-10 09:32:35', 'admin', '[\"view_dashboard\",\"manage_transactions\",\"view_reports\",\"manage_users\",\"view_analytics\",\"manage_categories\",\"manage_settings\",\"view_logs\",\"view_all_transactions\",\"view_all_user_data\",\"access_ledger\",\"manage_categories\",\"export_data\",\"perform_bulk_operations\",\"manage_notifications\",\"view_activity_logs\"]', 1, '2025-08-10 09:32:35', '$2y$12$FM5nGQs14uIo92UzzVcutu1T6upV5ogZiuNMtQVtvxlUM89lmvqY.', NULL, NULL, NULL, 0, '2025-08-10 09:32:35', '2025-08-10 09:50:31'),
(3, 'MOHAMMAD ABDUL MANNAN', 'mdmannan580@gmail.com', 'BDT', 'KWD', '৳', 'د.ك', '400.2877', 'system', 'neutral', 'UTC', 'Y-m-d', 'H:i', NULL, 'exchangerate-api.com', NULL, 'super_admin', '[\"manage_users\",\"manage_admins\",\"view_analytics\",\"manage_transactions\",\"manage_categories\",\"manage_settings\"]', 1, NULL, '$2y$12$4J.s68en8cEx81QIsB0OTuQwBQZ3KQD88N3zPed2zLOv.Co4npEnu', NULL, NULL, NULL, 0, '2025-08-10 10:16:59', '2025-08-10 10:42:48');

